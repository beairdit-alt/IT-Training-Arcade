
const DEFAULT={xp:0,progress:{},badges:[],connections:{},dhcp:{}};
function state(){let s=JSON.parse(localStorage.getItem("ens4")||"null");if(!s){s=structuredClone(DEFAULT);save(s)}return s}
function save(s){localStorage.setItem("ens4",JSON.stringify(s))}
function award(id,xp=100,badge=null){let s=state();if(!s.progress[id]){s.progress[id]={done:true};s.xp+=xp;if(badge&&!s.badges.includes(badge))s.badges.push(badge);save(s);toast(`Mission complete! +${xp} XP${badge?" • Badge: "+badge:""}`)}}
function toast(msg){let t=document.getElementById("toast");if(!t){t=document.createElement("div");t.id="toast";t.className="toast";document.body.appendChild(t)}t.textContent=msg;t.style.display="block";setTimeout(()=>t.style.display="none",2600)}
function topnav(){return ``}
document.addEventListener("DOMContentLoaded",()=>{let n=document.getElementById("nav");if(n)n.innerHTML=topnav();let s=state();document.querySelectorAll("[data-xp]").forEach(e=>e.textContent=s.xp)});

const FLOW=["01","02","03","04","05","06","07","08","09","10","11","12","13"];
function campaignState(){let s=state(); if(!s.unlocked){s.unlocked=["01"]; save(s)} return s}
function isUnlocked(id){return true}
function finishModule(id,xp=150,badge=null){
  award(id,xp,badge);
  let s=campaignState();
  const i=FLOW.indexOf(id);
  if(i>=0 && i<FLOW.length-1 && !s.unlocked.includes(FLOW[i+1])) s.unlocked.push(FLOW[i+1]);
  save(s);
  toast("Module complete — next mission unlocked");
}
function campaignNav(active){
 const names={
 "01":"Subnetting","02":"pfSense Firewall","03":"Aruba Switch","04":"Physical Rack","05":"Dell iDRAC",
 "06":"Server Install","07":"Windows Server","08":"Linux Server","09":"DNS & DHCP","10":"Active Directory",
 "11":"Client Deployment","12":"Wireless","13":"Troubleshooting"
 };
 const files={
 "01":"01_subnet_planner.html","02":"02_pfsense.html","03":"03_aruba.html","04":"rack.html","05":"05_idrac.html",
 "06":"06_server_install.html","07":"07_windows_server.html","08":"08_linux_server.html","09":"dhcp_server.html",
 "10":"10_active_directory.html","11":"11_clients.html","12":"12_wireless.html","13":"13_troubleshooting.html"
 };
 let s=campaignState();
 return `<div class="card campaign-nav"><span class="badge">GUIDED CAMPAIGN</span><h3>Build Order</h3>`+
 FLOW.map((id,i)=>`<a class="camp-item ${active===id?"active":""} ${s.progress[id]?.done?"done":""}" href="${files[id]}">
 <div class="camp-num">${s.progress[id]?.done?"✓":i+1}</div><div><b>${names[id]}</b><div class="muted">${s.progress[id]?.done?"Complete":"Open anytime"}</div></div></a>`).join("")+`</div>`;
}

const HELP_DATA={"index.html": {"title": "Network Lab Coach", "intro": "You can enter any module. The recommended learning order starts with subnetting so the addressing plan drives everything else.", "why": "Real network projects usually begin with design and documentation before device configuration.", "steps": ["Start with Subnetting if this is your first run.", "Use the rack image to understand where each device fits.", "Return here anytime to jump to another lab."], "hints": ["If you are unsure where to begin, start with Module 1.", "The firewall routes between VLANs; the switch carries VLANs; servers provide services.", "Nothing is locked, so practice any topic independently."], "answer": "Recommended path: Subnetting \u2192 pfSense \u2192 Aruba \u2192 Rack \u2192 iDRAC \u2192 Servers \u2192 DNS/DHCP \u2192 AD \u2192 Clients \u2192 Wireless \u2192 Troubleshooting."}, "01_subnet_planner.html": {"title": "Subnetting Coach", "intro": "Your goal is to create a clean VLAN-to-subnet plan.", "why": "Every gateway, DHCP scope, firewall interface, and server address depends on this plan being correct.", "steps": ["Match each VLAN to its /24 network.", "Use .1 as the default gateway in this simulation.", "Validate all rows before moving on."], "hints": ["VLAN 21 Users should use the 10.10.21.0 network.", "The network address ends in .0 and the gateway uses the first usable address.", "Keep the VLAN number aligned with the third octet in this lab."], "answer": "Admin 10.10.10.0/24 GW .1; Servers 10.10.20.0/24; Users 10.10.21.0/24; iDRAC 10.10.22.0/24; Wi-Fi 10.10.23.0/24; NetMgmt 10.10.99.0/24."}, "02_pfsense.html": {"title": "pfSense Coach", "intro": "Build the Layer 3 side of the network: VLAN interfaces, gateways, DHCP, and firewall policy.", "why": "pfSense becomes the default gateway for each VLAN and controls which networks may communicate.", "steps": ["Open Interfaces and build VLANs on igb1.", "Assign the gateway IP for each VLAN.", "Open Services and configure DHCP for Users.", "Open Firewall and add the required rules.", "Use Diagnostics to ping a client."], "hints": ["The trunk parent is igb1.", "Users are VLAN 21.", "User DHCP runs from 10.10.21.50 through 10.10.21.220.", "Internal DNS is 10.10.20.10.", "Users should not have unrestricted access to iDRAC."], "answer": "Create VLANs 10,20,21,22,23,99 on igb1. Gateways are 10.10.X.1. User DHCP: 10.10.21.50\u2013220, DNS 10.10.20.10."}, "03_aruba.html": {"title": "Aruba Switch Coach", "intro": "Create VLANs, assign ports, and build the uplink to pfSense.", "why": "The switch separates Layer 2 traffic. The trunk carries multiple VLANs to the firewall.", "steps": ["Enter configuration mode.", "Create VLANs 10,20,21,22,23,99.", "Use access/untagged ports for end devices.", "Tag port 48 in every VLAN.", "Set the management IP.", "Verify with show commands."], "hints": ["Try: configure terminal", "Then: vlan 20", "Inside a VLAN: tagged 48", "Management lives on VLAN 99.", "Verification commands include show vlan and show interfaces brief."], "answer": "Required VLANs: 10,20,21,22,23,99. Port 48 is tagged in all VLANs. Management IP: 10.10.99.2/24."}, "rack.html": {"title": "Rack Coach", "intro": "Connect the logical network to the physical equipment.", "why": "A correct configuration still fails if the wrong NIC, switch port, or management port is cabled.", "steps": ["Find pfSense and the Aruba switch.", "Trace the pfSense LAN/trunk to switch port 48.", "Connect server production NICs to VLAN 20 ports.", "Connect iDRAC ports to VLAN 22 ports.", "Connect the AP to the wireless network."], "hints": ["Production NIC and iDRAC are different ports.", "Front view is best for health and drives; rear view is best for cabling.", "The firewall-to-switch link is the trunk."], "answer": "pfSense LAN \u2192 Aruba 48; server NICs \u2192 VLAN20; iDRAC \u2192 VLAN22; AP \u2192 VLAN23."}, "05_idrac.html": {"title": "iDRAC Coach", "intro": "Configure out-of-band management separately from the server operating system.", "why": "iDRAC lets administrators manage power, health, firmware, storage, and console access even if the OS is down.", "steps": ["Check Overview for health.", "Open iDRAC Settings \u2192 Network.", "Choose Dedicated NIC.", "Assign a 10.10.22.x address.", "Use gateway 10.10.22.1 and VLAN 22.", "Launch Virtual Console."], "hints": ["Do not use the production server NIC for this task.", "The management subnet is 10.10.22.0/24.", "Use the Dedicated NIC option.", "Virtual Console should work independently of the OS."], "answer": "Dedicated NIC, 10.10.22.x/24, gateway 10.10.22.1, VLAN 22."}, "06_server_install.html": {"title": "Server Install Coach", "intro": "Install the OS and give the server predictable network settings.", "why": "Infrastructure servers should have stable addressing so DNS, AD, DHCP, and management tools can reliably find them.", "steps": ["Choose Windows or Linux.", "Set a meaningful hostname.", "Use a 10.10.20.x static address.", "Gateway is 10.10.20.1.", "Use internal DNS."], "hints": ["Windows example: WIN-SRV01.", "Linux example: LIN-SRV01.", "The Server VLAN is VLAN 20.", "Internal DNS is typically your DNS/DC server."], "answer": "Use Server VLAN addressing: 10.10.20.x/24 with gateway 10.10.20.1."}, "07_windows_server.html": {"title": "Windows Server Coach", "intro": "Turn Windows Server into core infrastructure.", "why": "AD DS manages identity, DNS lets domain clients locate services, and DHCP automates client addressing.", "steps": ["Add AD DS, DNS, and DHCP roles.", "Promote the server to a new forest.", "Create networklab.local.", "Add DNS A record dc01 \u2192 10.10.20.10.", "Create the Users DHCP scope.", "Return to Dashboard and verify services."], "hints": ["All three roles are required in this exercise.", "The domain name is networklab.local.", "The Users pool is 10.10.21.50\u2013220.", "Router option is 10.10.21.1.", "DNS option is 10.10.20.10."], "answer": "AD DS + DNS + DHCP; forest networklab.local; A record dc01=10.10.20.10; Users scope 10.10.21.50\u2013220."}, "08_linux_server.html": {"title": "Linux Server Coach", "intro": "Use the shell to inspect networking and manage services.", "why": "Linux administrators diagnose the network first, then inspect services, packages, and logs.", "steps": ["Run ip addr.", "Run ip route.", "Check SSH status.", "Install bind9.", "Install isc-dhcp-server.", "Check bind9 status.", "Review DHCP logs."], "hints": ["Start with: ip addr", "Routing table: ip route", "Service checks use systemctl status ...", "Logs can be viewed with journalctl."], "answer": "Run: ip addr; ip route; systemctl status ssh; sudo apt install bind9; sudo apt install isc-dhcp-server; systemctl status bind9; journalctl -u isc-dhcp-server."}, "dhcp_server.html": {"title": "DHCP Coach", "intro": "Build a working User VLAN scope using Windows or Linux.", "why": "DHCP provides IP, mask, gateway, and DNS automatically so clients can communicate consistently.", "steps": ["Choose Windows or Linux path.", "Use the Users subnet.", "Define the lease pool.", "Set gateway and DNS.", "Activate/restart the service.", "Test a client lease."], "hints": ["Users are on 10.10.21.0/24.", "Pool starts at .50 and ends at .220.", "Gateway is 10.10.21.1.", "DNS server is 10.10.20.10."], "answer": "Network 10.10.21.0/24; pool 10.10.21.50\u2013220; router 10.10.21.1; DNS 10.10.20.10."}, "09_dns_dhcp.html": {"title": "DNS & DHCP Coach", "intro": "Use the DHCP Server Challenge for this module.", "why": "DNS and DHCP are separate services that work together to make client networking usable.", "steps": ["Configure addressing first.", "Build DHCP scope.", "Verify internal DNS.", "Test client lease."], "hints": ["DHCP gives the client settings.", "DNS resolves names to IP addresses.", "Use the internal DNS server for domain clients."], "answer": "Use the DHCP Server Challenge page for the full simulation."}, "10_active_directory.html": {"title": "Active Directory Coach", "intro": "Build a clean OU structure for administration and Group Policy.", "why": "OUs organize objects for management and policy\u2014not just for appearance.", "steps": ["Create Admin.", "Create Faculty.", "Create Students.", "Create Servers.", "Create Computers.", "Verify all OUs exist."], "hints": ["OU names must match exactly in this lab.", "Think about which objects need different policies.", "Servers and regular Computers should be separated."], "answer": "Required OUs: Admin, Faculty, Students, Servers, Computers."}, "11_clients.html": {"title": "Client Deployment Coach", "intro": "Use one Windows client to test the entire infrastructure stack.", "why": "A domain join depends on DHCP, routing, DNS, and Active Directory all working together.", "steps": ["Run ipconfig /all.", "Ping the gateway.", "Use nslookup.", "Join networklab.local."], "hints": ["The client should receive 10.10.21.x.", "Gateway should be 10.10.21.1.", "DNS should be 10.10.20.10.", "Public DNS is not appropriate for locating the AD domain."], "answer": "Expected client: 10.10.21.x, GW 10.10.21.1, DNS 10.10.20.10, then join networklab.local."}, "12_wireless.html": {"title": "Wireless Coach", "intro": "Create an SSID and map wireless traffic into VLAN 23.", "why": "The SSID is the user-facing network name; the VLAN determines where that traffic belongs on the wired network.", "steps": ["Create SSID NETWORKLAB-WIFI.", "Set VLAN 23.", "Use WPA2 or WPA3.", "Set 5 GHz channel Auto or 36.", "Apply and connect a test client."], "hints": ["Use secure authentication\u2014not Open.", "The wireless gateway is 10.10.23.1.", "A good test client should receive 10.10.23.x.", "A 169.254.x.x address means DHCP failed."], "answer": "SSID NETWORKLAB-WIFI; VLAN23; WPA2/WPA3; GW 10.10.23.1."}, "13_troubleshooting.html": {"title": "Troubleshooting Coach", "intro": "Diagnose the symptom before changing anything.", "why": "Good troubleshooting follows evidence from the client through the network path instead of guessing.", "steps": ["Inspect the client IP configuration.", "Interpret the 169.254.x.x address.", "Check VLAN 21.", "Trace the DHCP path.", "Confirm gateway and DHCP server reachability."], "hints": ["169.254.x.x is APIPA.", "APIPA usually means the client did not receive DHCP.", "The link light being on only confirms physical link.", "Focus on VLAN 21 and its DHCP path."], "answer": "First check ipconfig /all. APIPA indicates DHCP failure. Investigate VLAN 21 \u2192 gateway/relay \u2192 DHCP server."}};

Object.assign(HELP_DATA,{
"backup_server.html": {
  "title": "Proxmox Backup Server Coach",
  "intro": "Use PBS to inspect the backup datastore, review jobs, and verify that backups can be trusted.",
  "why": "Backups are only useful if they are monitored, verified, and restorable when the network has a problem.",
  "steps": [
    "Open Dashboard and confirm the backup server is online.",
    "Review the Datastore and check capacity and status.",
    "Open Backup Jobs and run a backup task.",
    "Open Verify Jobs and confirm the latest backup passes verification.",
    "Review Prune and GC to understand retention and cleanup."
  ],
  "hints": [
    "Look for a healthy datastore status first.",
    "A successful backup job should finish with TASK OK.",
    "Verification is separate from backup creation.",
    "Retention and prune settings help manage space."
  ],
  "answer": "Healthy PBS workflow: datastore available, backup job runs successfully, verify passes, and retention/prune are configured."
},
"ups.html": {
  "title": "UPS Monitoring Coach",
  "intro": "Use the APC UPS interface to monitor power health, load, runtime, and battery condition.",
  "why": "A UPS protects network equipment from power loss and gives enough time for safe shutdown or continued operation.",
  "steps": [
    "Open Status and record load, battery charge, and runtime.",
    "Review Input and Output power values.",
    "Open Control and run a self-test.",
    "Simulate a battery transfer and observe the runtime message.",
    "Open Logs and review the recorded events."
  ],
  "hints": [
    "The load is shown as a percentage and watt estimate.",
    "Runtime changes when the UPS is on battery.",
    "A passed self-test is a good sign that the battery and transfer path are working.",
    "The event log helps explain recent power events."
  ],
  "answer": "Healthy UPS signs: online state, reasonable load, good battery health, successful self-test, and clear event logs."
},
"rack.html": {
  "title": "Physical Rack Coach",
  "intro": "Use this page as a visual reference for where the firewall, switch, servers, backup server, and UPS are physically located.",
  "why": "Students need to connect the logical design to the actual hardware layout in the rack.",
  "steps": [
    "Identify the pfSense firewall and Aruba switch.",
    "Find the Windows and Linux servers.",
    "Locate the backup server and the UPS.",
    "Return to the NOC to open each simulator from the rack image."
  ],
  "hints": [
    "The rack page is a visual reference, not the main control page.",
    "Use the NOC center rack image to launch device simulators.",
    "Front view helps with hardware identification; rear view helps with cabling."
  ],
  "answer": "Use the rack page to recognize device locations, then return to the NOC for interactive simulation."
}
});


/* V14 - Exact command/value hints for students */
Object.assign(HELP_DATA,{
"01_subnet_planner.html":{
  "title":"Subnetting Coach",
  "intro":"Complete the full IPv4 addressing plan for each VLAN.",
  "why":"A network administrator must know the network address, usable host range, broadcast address, default gateway, and subnet mask before configuring devices.",
  "steps":[
    "Enter the network in CIDR notation.",
    "Enter the full usable host range.",
    "Enter the broadcast address.",
    "Enter the default gateway.",
    "Enter the subnet mask.",
    "Validate the completed addressing plan."
  ],
  "hints":[
    "VLAN 10: Network 10.10.10.0/24 | Usable 10.10.10.1 - 10.10.10.254 | Broadcast 10.10.10.255 | Gateway 10.10.10.1 | Mask 255.255.255.0",
    "VLAN 20: Network 10.10.20.0/24 | Usable 10.10.20.1 - 10.10.20.254 | Broadcast 10.10.20.255 | Gateway 10.10.20.1 | Mask 255.255.255.0",
    "VLAN 21: Network 10.10.21.0/24 | Usable 10.10.21.1 - 10.10.21.254 | Broadcast 10.10.21.255 | Gateway 10.10.21.1 | Mask 255.255.255.0",
    "VLAN 22: Network 10.10.22.0/24 | Usable 10.10.22.1 - 10.10.22.254 | Broadcast 10.10.22.255 | Gateway 10.10.22.1 | Mask 255.255.255.0",
    "VLAN 23: Network 10.10.23.0/24 | Usable 10.10.23.1 - 10.10.23.254 | Broadcast 10.10.23.255 | Gateway 10.10.23.1 | Mask 255.255.255.0",
    "VLAN 99: Network 10.10.99.0/24 | Usable 10.10.99.1 - 10.10.99.254 | Broadcast 10.10.99.255 | Gateway 10.10.99.1 | Mask 255.255.255.0"
  ],
  "answer":"All VLANs use /24 (255.255.255.0). For each subnet: .0 is the network address, .1-.254 are usable hosts, .255 is broadcast, and .1 is used as the gateway in this lab."
},
"03_aruba.html":{
  "title":"Aruba Switch Coach",
  "intro":"Configure VLANs and the trunk by entering the commands in the Aruba CLI. Press Enter after each command.",
  "why":"The switch must carry each VLAN to pfSense and provide a separate management network.",
  "steps":["Enter configuration mode.","Create each VLAN.","Tag port 48 in every VLAN.","Set the management IP.","Verify the configuration."],
  "hints":[
    "Type: configure terminal",
    "Type: vlan 10",
    "Type: tagged 48",
    "Type: vlan 20",
    "Type: tagged 48",
    "Type: vlan 21",
    "Type: tagged 48",
    "Type: vlan 22",
    "Type: tagged 48",
    "Type: vlan 23",
    "Type: tagged 48",
    "Type: vlan 99",
    "Type: tagged 48",
    "Type: ip address 10.10.99.2 255.255.255.0",
    "Type: show vlan",
    "Type: show interfaces brief"
  ],
  "answer":"configure terminal\nvlan 10\ntagged 48\nvlan 20\ntagged 48\nvlan 21\ntagged 48\nvlan 22\ntagged 48\nvlan 23\ntagged 48\nvlan 99\ntagged 48\nip address 10.10.99.2 255.255.255.0\nshow vlan\nshow interfaces brief"
},
"05_idrac.html":{
  "title":"iDRAC Coach",
  "intro":"Configure the dedicated out-of-band management interface.",
  "why":"iDRAC remains available even when the operating system is down.",
  "steps":["Open iDRAC Settings → Network.","Select Dedicated NIC.","Enter the IPv4 settings.","Set VLAN 22.","Apply the configuration.","Launch Virtual Console."],
  "hints":[
    "NIC Selection: Dedicated",
    "IPv4 Address: 10.10.22.10",
    "Subnet Mask: 255.255.255.0",
    "Gateway: 10.10.22.1",
    "VLAN ID: 22",
    "Click Apply, then open Virtual Console."
  ],
  "answer":"Dedicated NIC; IP 10.10.22.10; mask 255.255.255.0; gateway 10.10.22.1; VLAN 22."
},
"06_server_install.html":{
  "title":"Server Install Coach",
  "intro":"Install the server OS and give it predictable network settings.",
  "why":"Infrastructure services need stable addresses so DNS, AD, DHCP, and management tools can reliably locate them.",
  "steps":["Choose Windows or Linux.","Enter a hostname.","Enter a static IP.","Enter the gateway.","Enter internal DNS.","Install."],
  "hints":[
    "Windows example hostname: WIN-SRV01",
    "Static IP: 10.10.20.10",
    "Gateway: 10.10.20.1",
    "DNS: 10.10.20.10",
    "Then click Install."
  ],
  "answer":"Windows: WIN-SRV01 / 10.10.20.10 / 10.10.20.1 / DNS 10.10.20.10. Linux example: LIN-SRV01 / 10.10.20.20 / 10.10.20.1 / DNS 10.10.20.10."
},
"07_windows_server.html":{
  "title":"Windows Server Coach",
  "intro":"Configure Windows Server roles and the network services used by the domain.",
  "why":"AD DS, DNS, and DHCP depend on correct addressing and service configuration.",
  "steps":["Enable the required roles.","Configure the domain.","Configure DNS.","Configure the DHCP scope.","Verify the server."],
  "hints":[
    "Check role: Active Directory Domain Services",
    "Check role: DNS Server",
    "Check role: DHCP Server",
    "Domain name: networklab.local",
    "DNS zone: networklab.local",
    "DNS host: dc01",
    "DNS host IP: 10.10.20.10",
    "DHCP start: 10.10.21.50",
    "DHCP end: 10.10.21.220",
    "DHCP gateway: 10.10.21.1",
    "DHCP DNS: 10.10.20.10"
  ],
  "answer":"AD DS + DNS + DHCP; domain networklab.local; dc01 = 10.10.20.10; DHCP 10.10.21.50-10.10.21.220; GW 10.10.21.1; DNS 10.10.20.10."
},
"08_linux_server.html":{
  "title":"Linux Server Coach",
  "intro":"Run the required Linux administration commands in the terminal. Press Enter after each command.",
  "why":"These commands verify addressing, routing, SSH, DNS, and DHCP services from the command line.",
  "steps":["Verify the IP address.","Verify the default route.","Check SSH.","Install DNS.","Install DHCP.","Check DNS.","Review DHCP logs."],
  "hints":[
    "Type: ip addr",
    "Type: ip route",
    "Type: systemctl status ssh",
    "Type: sudo apt install bind9",
    "Type: sudo apt install isc-dhcp-server",
    "Type: systemctl status bind9",
    "Type: journalctl -u isc-dhcp-server"
  ],
  "answer":"ip addr\nip route\nsystemctl status ssh\nsudo apt install bind9\nsudo apt install isc-dhcp-server\nsystemctl status bind9\njournalctl -u isc-dhcp-server"
},
"09_dns_dhcp.html":{
  "title":"DNS & DHCP Coach",
  "intro":"Build the User VLAN DHCP scope using the exact addressing plan.",
  "why":"Clients need the correct network, lease range, gateway, and DNS server to function.",
  "steps":["Enter the network.","Enter the lease range.","Enter the gateway.","Enter DNS.","Save/verify the scope."],
  "hints":[
    "Network: 10.10.21.0/24",
    "Start address: 10.10.21.50",
    "End address: 10.10.21.220",
    "Gateway: 10.10.21.1",
    "DNS server: 10.10.20.10"
  ],
  "answer":"Network 10.10.21.0/24; pool 10.10.21.50-10.10.21.220; gateway 10.10.21.1; DNS 10.10.20.10."
},
"10_active_directory.html":{
  "title":"Active Directory Coach",
  "intro":"Create the organizational structure for the classroom domain.",
  "why":"OUs make users and computers easier to manage with delegation and Group Policy.",
  "steps":["Create the required OUs.","Verify the OU structure."],
  "hints":[
    "Enter OU name: Students",
    "Enter OU name: Instructors",
    "Enter OU name: Servers",
    "Enter OU name: Workstations"
  ],
  "answer":"Create OUs named Students, Instructors, Servers, and Workstations."
},
"11_clients.html":{
  "title":"Client Deployment Coach",
  "intro":"Configure a client to receive network settings and join the domain.",
  "why":"A client must have working IP, gateway, and DNS settings before domain services can work.",
  "steps":["Obtain an address.","Verify DNS.","Test the gateway.","Join the domain."],
  "hints":[
    "Expected client IP range: 10.10.21.50-10.10.21.220",
    "Expected gateway: 10.10.21.1",
    "Expected DNS: 10.10.20.10",
    "Domain to join: networklab.local"
  ],
  "answer":"Client should receive VLAN21 DHCP settings, use DNS 10.10.20.10, and join networklab.local."
},
"12_wireless.html":{
  "title":"Wireless Coach",
  "intro":"Configure the classroom WLAN and place wireless clients on VLAN 23.",
  "why":"The SSID, VLAN, security, gateway, and channel settings determine how wireless clients reach the network.",
  "steps":["Enter SSID.","Set VLAN.","Set gateway.","Select WPA2/WPA3 security.","Choose channel settings.","Apply."],
  "hints":[
    "SSID: NetworkLab-WiFi",
    "VLAN: 23",
    "Gateway: 10.10.23.1",
    "Security: WPA2/WPA3",
    "Use an appropriate non-overlapping channel."
  ],
  "answer":"SSID NetworkLab-WiFi; VLAN 23; gateway 10.10.23.1; WPA2/WPA3 security."
},
"13_troubleshooting.html":{
  "title":"Troubleshooting Coach",
  "intro":"Use the symptoms to choose the correct first troubleshooting actions.",
  "why":"A structured troubleshooting process prevents random changes and helps isolate the fault quickly.",
  "steps":["Check the client configuration.","Interpret the APIPA address.","Trace the DHCP/VLAN path.","Resolve the incident."],
  "hints":[
    "Select first client command: ipconfig /all",
    "Select 169.254.x.x meaning: APIPA / DHCP failed",
    "Select next infrastructure area: VLAN 21 DHCP path"
  ],
  "answer":"ipconfig /all → APIPA / DHCP failed → VLAN 21 DHCP path."
}
});

function currentHelpKey(){
  let p=location.pathname.split('/').pop()||'index.html';
  return HELP_DATA[p]?p:'index.html';
}
function ensureHelpUI(){
  if(document.getElementById('helpFab')) return;
  const fab=document.createElement('button');fab.id='helpFab';fab.className='help-fab';fab.textContent='💡 Guided Help';
  fab.onclick=()=>document.getElementById('helpPanel').classList.toggle('open');
  document.body.appendChild(fab);
  const panel=document.createElement('div');panel.id='helpPanel';panel.className='help-panel';
  document.body.appendChild(panel);renderHelp();
}
let helpHintIndex=0;
function renderHelp(){
  const h=HELP_DATA[currentHelpKey()]||HELP_DATA['index.html'];
  const panel=document.getElementById('helpPanel'); if(!panel)return;
  let steps=h.steps.map((s,i)=>`<div class="help-step ${i===0?'current':''}"><b>${i+1}.</b> ${s}</div>`).join('');
  panel.innerHTML=`<div class="help-head"><h3>💡 ${h.title}</h3><button onclick="document.getElementById('helpPanel').classList.remove('open')">✕</button></div>
  <div class="coach-bubble">${h.intro}</div>
  <div class="help-why"><b>Why this matters</b><br>${h.why}</div>
  <h4>Guided Steps</h4>${steps}
  <div id="hintBox" class="help-hint"><b>Hint 1</b><br>${h.hints[0]}</div>
  <div id="answerBox" class="help-answer"><b>Show Me</b><br>${h.answer}</div>
  <div class="help-actions">
    <button onclick="nextHint()">Next Hint</button>
    <button onclick="showAnswer()">Show Exact Values / Commands</button>
    <button onclick="resetHelp()">Reset Help</button>
  </div>`;
}
function nextHint(){
  const h=HELP_DATA[currentHelpKey()]||HELP_DATA['index.html'];
  helpHintIndex=(helpHintIndex+1)%h.hints.length;
  const b=document.getElementById('hintBox');if(b)b.innerHTML=`<b>Hint ${helpHintIndex+1}</b><br>${h.hints[helpHintIndex]}`;
}
function showAnswer(){
  const b=document.getElementById('answerBox'); if(b)b.style.display='block';
}
function resetHelp(){
  helpHintIndex=0; const b=document.getElementById('answerBox');if(b)b.style.display='none';renderHelp();
}



function exactHelpForCurrentPage(){
 const p=(location.pathname.split('/').pop()||'');
 return HELP_DATA[p] || null;
}
let builtInGuideHint=0;

function verifyCurrentSimulator(){
 const result=document.getElementById('builtinGuideResult');
 const candidates=[
  'verifyAruba','verifyIdr','verifyWin','verifyL','verifyWifi',
  'verifyLab','verifyAll','checkAll','grade','validateAll'
 ];
 for(const fn of candidates){
   if(typeof window[fn]==='function'){
     try{
       window[fn]();
       if(result) result.innerHTML='<span style="color:#8ae69a">Verification command sent to this simulator. Review the simulator result.</span>';
       return;
     }catch(e){}
   }
 }
 const id=getCurrentModuleId();
 if(id){
   try{
     const s=state();
     if(s.progress && s.progress[id] && s.progress[id].done){
       if(result) result.innerHTML='<span style="color:#8ae69a">This module is marked complete.</span>';
     }else{
       if(result) result.innerHTML='<span style="color:#ffd36b">Use the simulator controls to complete the tasks, then verify again.</span>';
     }
     return;
   }catch(e){}
 }
 if(result) result.innerHTML='<span style="color:#ffd36b">Complete the simulator tasks and use its built-in validation controls.</span>';
}

function nextBuiltInHint(){
 const h=exactHelpForCurrentPage();
 if(!h || !h.hints || !h.hints.length) return;
 builtInGuideHint=(builtInGuideHint+1)%h.hints.length;
 const box=document.getElementById('builtinHint');
 if(box) box.innerHTML='<b>Hint '+(builtInGuideHint+1)+'</b><br>'+h.hints[builtInGuideHint];
 const steps=document.querySelectorAll('.builtin-student-guide .guide-step');
 steps.forEach((e,i)=>{
   e.classList.toggle('done',i<builtInGuideHint);
   e.classList.toggle('current',i===Math.min(builtInGuideHint,steps.length-1));
 });
}

function showBuiltInExact(){
 const box=document.getElementById('builtinExact');
 if(box) box.style.display='block';
}

function resetBuiltInGuide(){
 builtInGuideHint=0;
 const h=exactHelpForCurrentPage();
 if(!h) return;
 const box=document.getElementById('builtinHint');
 if(box) box.innerHTML='<b>Hint 1</b><br>'+h.hints[0];
 const exact=document.getElementById('builtinExact');
 if(exact) exact.style.display='none';
 document.querySelectorAll('.builtin-student-guide .guide-step').forEach((e,i)=>{
   e.classList.toggle('current',i===0);
   e.classList.remove('done');
 });
 const result=document.getElementById('builtinGuideResult');
 if(result) result.textContent='';
}

function buildBuiltInStudentGuide(){
 const h=exactHelpForCurrentPage();
 if(!h) return; // Tools/reference pages without module help stay clean.
 if(document.querySelector('.builtin-student-guide')) return;

 // Remove old floating help UI if present.
 const oldFab=document.getElementById('helpFab');
 const oldPanel=document.getElementById('helpPanel');
 if(oldFab) oldFab.remove();
 if(oldPanel) oldPanel.remove();

 const guide=document.createElement('aside');
 guide.className='builtin-student-guide';
 guide.innerHTML=`
   <div class="guide-title">Student Guide • ${h.title.replace(' Coach','')}</div>
   <div class="guide-scroll">
     <div class="guide-intro">${h.intro}</div>
     <div class="guide-why"><b>Why this matters</b><br>${h.why}</div>
     <b>Guided Steps</b>
     ${h.steps.map((s,i)=>`<div class="guide-step ${i===0?'current':''}"><b>${i+1}.</b> ${s}</div>`).join('')}
     <div id="builtinHint" class="guide-hint"><b>Hint 1</b><br>${h.hints[0]}</div>
     <div id="builtinExact" class="guide-exact"><b>Exact Values / Commands</b><br>${h.answer}</div>
     <div class="guide-actions">
       <button onclick="nextBuiltInHint()">Next Hint</button>
       <button onclick="showBuiltInExact()">Show Exact Values</button>
       <button class="verify-btn" onclick="verifyCurrentSimulator()">Verify Lab</button>
       <button onclick="resetCurrentModule()">Reset Lab</button>
       <button onclick="resetBuiltInGuide()">Reset Guide</button>
     </div>
     <div id="builtinGuideResult" class="guide-result"></div>
   </div>`;
 document.body.appendChild(guide);
}
document.addEventListener('DOMContentLoaded',()=>setTimeout(buildBuiltInStudentGuide,0));


function getCurrentModuleId(){
 const p=(location.pathname.split('/').pop()||'index.html');
 const map={
 '01_subnet_planner.html':'01','02_pfsense.html':'02','03_aruba.html':'03',
 'rack.html':'04','04_cabling.html':'04','05_idrac.html':'05','06_server_install.html':'06',
 '07_windows_server.html':'07','08_linux_server.html':'08','dhcp_server.html':'09',
 '09_dns_dhcp.html':'09','10_active_directory.html':'10','11_clients.html':'11',
 '12_wireless.html':'12','13_troubleshooting.html':'13'
 };
 return map[p]||null;
}
function resetCurrentModule(){
 const id=getCurrentModuleId();
 if(!id){alert("This page does not have a module-specific reset.");return}
 if(!confirm("Reset only this module? Your overall progress and other modules will remain."))return;
 let s=state();
 if(s.progress && s.progress[id]) delete s.progress[id];
 // Clear module-specific saved state if any exists
 if(s.moduleData && s.moduleData[id]) delete s.moduleData[id];
 save(s);
 sessionStorage.clear();
 localStorage.setItem("ens4",JSON.stringify(s));
 alert("This module has been reset.");
 location.reload();
}
function resetEntireNetwork(){
 if(!confirm("Reset the ENTIRE network simulation? This clears XP, badges, completed modules, and saved configurations."))return;
 if(!confirm("Final confirmation: erase all simulator progress and start fresh?"))return;
 localStorage.removeItem("ens4");
 localStorage.removeItem("ens_state");
 sessionStorage.clear();
 alert("Entire network simulation reset.");
 location.href="index.html";
}
function ensureResetUI(){
 if(document.getElementById("resetFab"))return;
 const fab=document.createElement("button");
 fab.id="resetFab";fab.className="reset-fab";fab.textContent="↻ Reset";
 fab.onclick=()=>document.getElementById("resetPanel").classList.toggle("open");
 document.body.appendChild(fab);

 const panel=document.createElement("div");
 panel.id="resetPanel";panel.className="reset-panel";
 panel.innerHTML=`<h3>Reset Options</h3>
 <p class="muted">Use these when a student wants to retry a lab or restart the entire simulator.</p>
 <button class="safe" onclick="resetCurrentModule()">Reset This Module</button>
 <button class="danger" onclick="resetEntireNetwork()">Reset Entire Network</button>
 <button onclick="document.getElementById('resetPanel').classList.remove('open')">Cancel</button>
 <div class="callout"><b>Reset This Module</b> keeps XP/progress from other modules.<br><br><b>Reset Entire Network</b> clears all simulator progress.</div>`;
 document.body.appendChild(panel);
}
document.addEventListener("DOMContentLoaded",()=>setTimeout(ensureResetUI,0));
