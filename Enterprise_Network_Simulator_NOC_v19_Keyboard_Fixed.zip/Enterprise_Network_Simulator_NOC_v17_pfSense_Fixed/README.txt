Enterprise Network Simulator v7 - Realistic Open Labs

Open index.html.

Key changes:
- Every module is accessible immediately. Nothing is locked.
- Recommended order is still visible.
- pfSense: Dashboard, VLANs, DHCP, Firewall Rules, Status, Diagnostics.
- Aruba: 48-port front panel, CLI, VLAN/trunk and management configuration.
- Dell iDRAC: Overview, Network, Storage, Firmware/Maintenance, Virtual Console.
- Windows Server: Server Manager, Roles, AD DS, DNS, DHCP.
- Linux Server: terminal commands, services, package installs, logs.
- Wireless: SSID, VLAN, WPA2/WPA3, radio channel, connected client testing.
- Rack images remain included in assets/.


V8 Guided Help Coach
- Floating Guided Help button on every page
- Step-by-step task guidance
- Why-this-matters explanations
- Progressive hints
- Optional exact values/commands reveal
- Available in all labs without blocking student progress


V9 Reset Controls
- Floating Reset button on every page
- Reset This Module: clears only the current lab's completion/state
- Reset Entire Network: clears XP, badges, all progress, and saved simulator state
- Double confirmation for full reset
